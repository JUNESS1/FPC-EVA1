/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_2_datos;

/**
 *
 * @author equipo
 */
public class EVA1_2_DATOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //;SIGNIFICA FIN DE LA LINEA
        //"    " -- CADENA DE TEXTO. DATO
        System.out.println("JUNESSY TORRES");
        //NUMEROS ENTEROS
        System.out.println(1000);
        //NUMEROS DECIMALES
        System.out.println(500.3);
        //VALORES LÓGICOS (VERDADERO O FALSO)
        //true false
        System.out.println(true);
        //CARACTERES INDIVIDUALES
        //COSAS DISTINTAS 
        System.out.println('c');//CARACTER
        System.out.println("c");//CADENA DE TEXTO
    }
    
}
