/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package isc_eva1_3_datos_25550471;

/**
 *
 * @author equipo
 */
public class ISC_EVA1_3_DATOS_25550471 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("NOMBRE DEL ESTUDIANTE: ");
        System.out.println("JUNESSY TORRES");
        System.out.print("NÚMERO DE CONTROL: ");
        System.out.println(25550471);
        System.out.print("EDAD: ");
        System.out.println(18);
    }
    
}
