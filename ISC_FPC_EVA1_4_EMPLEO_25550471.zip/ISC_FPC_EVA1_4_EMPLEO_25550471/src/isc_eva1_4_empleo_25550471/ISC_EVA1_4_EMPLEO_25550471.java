/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package isc_eva1_4_empleo_25550471;

/**
 *
 * @author equipo
 */
public class ISC_EVA1_4_EMPLEO_25550471 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("EMPLEO: ");
        System.out.println("GESTOR DE COBRANZA");
        System.out.print("SALARIO: ");
        System.out.println(4500);
        System.out.print("HORAS A LA SEMANA: ");
        System.out.println(60);
        System.out.print("REQUIERE INGLÉS? ");
        System.out.print("FALSE");
    }
    
}
